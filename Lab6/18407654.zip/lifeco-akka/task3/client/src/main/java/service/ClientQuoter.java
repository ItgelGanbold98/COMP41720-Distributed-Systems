package service;

public class ClientQuoter {
}
