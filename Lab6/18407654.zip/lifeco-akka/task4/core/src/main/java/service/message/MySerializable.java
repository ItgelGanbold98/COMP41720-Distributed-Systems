package service.message;

public interface MySerializable {
}
