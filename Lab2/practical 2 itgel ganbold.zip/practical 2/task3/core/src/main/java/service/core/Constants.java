package service.core;

public interface Constants {
	public static final String BROKER_SERVICE = "bs-BrokerService";  
	public static final String GIRLS_ALLOWED_SERVICE = "qs-GirlsAllowedService";  
	public static final String AULD_FELLAS_SERVICE = "qs-AuldFellasService";  
	public static final String DODGY_GEEZERS_SERVICE = "qs-DodgyGeezersService";
}